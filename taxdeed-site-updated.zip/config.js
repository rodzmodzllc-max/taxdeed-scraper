// Both values are safe to expose publicly. The anon key only permits what the
// row-level security policies allow, and every table requires a signed-in user.
window.TDW_CONFIG = {
  supabaseUrl: "https://cqnnnvpbocafuvpzfbzu.supabase.co",
  supabaseAnonKey: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNxbm5udnBib2NhZnV2cHpmYnp1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODU5OTQyNjYsImV4cCI6MjEwMTU3MDI2Nn0.hgQhS4sYWtu8fDKrRSRQdbmbbebnifXoq2xbMrH0yZA"
};
