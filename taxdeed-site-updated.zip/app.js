import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cfg = window.TDW_CONFIG || {};
if (!cfg.supabaseUrl || cfg.supabaseUrl.includes("YOUR-PROJECT-REF")) {
  document.body.innerHTML = '<div style="padding:2rem;font-family:sans-serif">' +
    '<h2>Not configured</h2><p>Edit <code>config.js</code> with your Supabase project URL and anon key, then redeploy.</p></div>';
  throw new Error("config.js not filled in");
}

// sessionStorage rather than the default localStorage: the token lives only as
// long as the tab/window does, so closing the browser signs you out. Trade-off
// is that a brand-new tab needs a fresh sign-in.
const sb = createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, {
  auth: {
    storage: window.sessionStorage,
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: false
  }
});

// Idle sign-out. Change IDLE_MINUTES to taste.
const BUILD = "v6 · 2026-08-06";
const IDLE_MINUTES = 5;    // silent sign-out after this much inactivity

// ---------------------------------------------------------------- constants
const DOC_STAMP_RATE = 0.007;
const RECORDING_FEE = 30;
const QUIET_TITLE_EST = 3000;
const TOP_PICK_RATIO = 12;
const SOON_DAYS = 14;

// How long a dropped/redeemed property stays visible before retiring itself.
// Longer if you flagged it — a favourite or a note means you wanted to
// remember it, and a redemption can reverse.
const GONE_HOURS_DEFAULT = 24;
const GONE_HOURS_FLAGGED = 48;

const GONE_STATUSES = ["dropped", "sold", "notfound"];
const isGone = p => GONE_STATUSES.includes(p.status);

const TYPE_ORDER = ["House", "Condo", "Townhome", "Mobile/Manuf.", "Vacant Lot", "Commercial", "Unknown"];
const LIEN_ORDER = ["clean", "flag", "serious", "unscreened"];
const LIEN_LABEL = { clean: "Clear", flag: "Flag", serious: "Serious", unscreened: "Unscreened" };
const STAGES = ["", "researched", "drove by", "called clerk", "bidding", "won", "passed"];

const COUNTY_INFO = {
  "Brevard":{fmt:"Online",note:"Deposit required in advance via the auction site. Register before the sale date."},
  "Indian River":{fmt:"Online",note:"Deposit required in advance via the auction site."},
  "Osceola":{fmt:"Online",note:"Deposit required in advance via the auction site."},
  "Seminole":{fmt:"Online",note:"Deposit required in advance via the auction site."},
  "Pasco":{fmt:"Online",note:"Deposit required in advance via the auction site."},
  "Polk":{fmt:"Online",note:"Deposit required in advance via the auction site."},
  "Lee":{fmt:"Online",note:"Deposit required in advance via the auction site."},
  "Charlotte":{fmt:"Online",note:"Shared site with foreclosure sales — confirm you are on a TAXDEED auction."},
  "Orange":{fmt:"Online",note:"Deposit required in advance via the auction site."},
  "Palm Beach":{fmt:"Online",note:"Three sale dates in play — check each property's own date."},
  "DeSoto":{fmt:"In person",note:"11:00am, DeSoto County Courthouse, 115 E Oak St, Arcadia — east entrance. Register by 10:30am with 5% of your highest bid in hand."},
  "Collier":{fmt:"In person",note:"1:00pm, Collier County Courthouse, 1st floor. Arrive 15 min early. Cannot register or bid by mail or internet."},
  "Hendry":{fmt:"In person",note:"Not on Realauction — Clerk runs the sale from a PDF notice. Confirm mechanics: (863) 675-5217."},
  "Hillsborough":{fmt:"Fixed price",note:"Lands Available parcels only — bought directly from the Clerk, no bidding."},
  "Glades":{fmt:"In person",note:"No sale currently scheduled; most recent notice was October 2025."}
};

// ------------------------------------------------------------------- state
let ALL = [];               // properties from the database
let NOTES = {};             // property_id -> [note rows]
let FAVS = new Set();
let HIDDEN = new Set();
let ME = null;

const state = {
  bidMin: null, bidMax: null, assessedMin: null,
  sortBy: "county", favoritesOnly: false, topPicksOnly: false, soonOnly: false,
  includeQT: false, maxBidPct: 40,
  statusView: "all",   // "all" | "live" | "gone" — driven by the header chips
  counties: new Set(), types: new Set(TYPE_ORDER), liens: new Set(LIEN_ORDER)
};

// A gone property retires itself once its window elapses, unless you flagged
// it. Anything still inside the window stays visible so a redemption that
// reverses, or one you wanted to track, doesn't silently vanish.
function goneExpired(p) {
  if (!isGone(p) || !p.gone_since) return false;
  const flagged = FAVS.has(p.id) || (NOTES[p.id] || []).some(n => n.body || n.stage);
  const hours = flagged ? GONE_HOURS_FLAGGED : GONE_HOURS_DEFAULT;
  return (Date.now() - Date.parse(p.gone_since)) > hours * 3600 * 1000;
}

// ------------------------------------------------------------------ helpers
const fmtMoney = n => "$" + Number(n).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtShort = n => "$" + Math.round(Number(n)).toLocaleString("en-US");
const esc = s => String(s == null ? "" : s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

function propType(p) {
  const s = (p.prop_type || "").toLowerCase();
  if (!s || s.includes("unknown")) return "Unknown";
  if (s.includes("vacant")) return "Vacant Lot";
  if (s.includes("mobile") || s.includes("manuf") || /\bmh\b/.test(s)) return "Mobile/Manuf.";
  if (s.includes("townhome")) return "Townhome";
  if (s.includes("condo")) return "Condo";
  if (s.includes("store") || s.includes("office") || s.includes("comm")) return "Commercial";
  if (s.includes("sfr") || s.includes("duplex") || /\d\s*\/\s*\d/.test(s)) return "House";
  return "Unknown";
}
const marketOf = p => Number(p.market || p.assessed || 0);
const valueRatio = p => (Number(p.bid) > 0 ? marketOf(p) / Number(p.bid) : 0);
const isTopPick = p => p.lien_level === "clean" && valueRatio(p) >= TOP_PICK_RATIO;
const homesteadSurcharge = p => (p.homestead ? Number(p.assessed || 0) / 2 : 0);
function trueCost(p) {
  const base = Number(p.bid) + homesteadSurcharge(p);
  return base + base * DOC_STAMP_RATE + RECORDING_FEE + (state.includeQT ? QUIET_TITLE_EST : 0);
}
const maxBid = p => marketOf(p) * (state.maxBidPct / 100);
function daysUntil(p) {
  if (!p.sale_date) return null;
  const d = new Date(p.sale_date + "T00:00:00");
  return Math.ceil((d - new Date().setHours(0, 0, 0, 0)) / 86400000);
}
function saleTime(p) {
  if (!p.sale_date) return Infinity;
  const t = Date.parse(p.sale_date);
  return isNaN(t) ? Infinity : t;
}
const countyNames = () => Array.from(new Set(ALL.map(p => p.county)));

// -------------------------------------------------------------------- auth
const gate = document.getElementById("authGate");
const app = document.getElementById("app");
const authMsg = document.getElementById("authMsg");

document.getElementById("authForm").addEventListener("submit", async e => {
  e.preventDefault();
  const btn = document.getElementById("signInBtn");
  btn.disabled = true; authMsg.className = "auth-msg"; authMsg.textContent = "Signing in...";
  const { error } = await sb.auth.signInWithPassword({
    email: document.getElementById("email").value.trim(),
    password: document.getElementById("password").value
  });
  btn.disabled = false;
  if (error) { authMsg.className = "auth-msg err"; authMsg.textContent = error.message; }
});

document.getElementById("signOutBtn").addEventListener("click", () => doSignOut(null));

async function doSignOut(reason) {
  stopIdleWatch();
  if (reason) sessionStorage.setItem("tdw_signout_reason", reason);
  await sb.auth.signOut();
  location.reload();
}

// ---- idle timeout -------------------------------------------------------
let lastActivity = Date.now();
let tick = null;

function markActive() { lastActivity = Date.now(); }
function stopIdleWatch() { if (tick) { clearInterval(tick); tick = null; } }
function startIdleWatch() {
  stopIdleWatch();
  markActive();
  tick = setInterval(() => {
    if (!ME) return;
    if (Date.now() - lastActivity >= IDLE_MINUTES * 60 * 1000) doSignOut("idle");
  }, 5000);
}

["mousemove", "mousedown", "keydown", "touchstart", "wheel", "scroll"].forEach(ev =>
  window.addEventListener(ev, markActive, { passive: true, capture: true })
);
document.addEventListener("visibilitychange", () => { if (!document.hidden) markActive(); });

sb.auth.onAuthStateChange((_e, session) => {
  if (session && session.user) { ME = session.user; showApp(); }
  else { gate.hidden = false; app.hidden = true; }
});

(async () => {
  const { data } = await sb.auth.getSession();
  if (data.session) { ME = data.session.user; showApp(); }
  else {
    gate.hidden = false;
    const why = sessionStorage.getItem("tdw_signout_reason");
    if (why === "idle") {
      authMsg.textContent = `Signed out after ${IDLE_MINUTES} minutes of inactivity.`;
      sessionStorage.removeItem("tdw_signout_reason");
    }
  }
})();

// -------------------------------------------------------------- data load
async function showApp() {
  gate.hidden = true; app.hidden = false;
  document.getElementById("generatedAt").textContent = "Loading...";
  await loadAll();
  state.counties = new Set(countyNames());
  buildAllChips();
  updateBadge();
  render();
  startIdleWatch();
}

async function loadAll() {
  const [props, notes, favs, hid] = await Promise.all([
    sb.from("properties").select("*").order("county").order("case_no"),
    sb.from("notes").select("*"),
    sb.from("favorites").select("property_id"),
    sb.from("hidden").select("property_id")
  ]);
  if (props.error) { document.getElementById("generatedAt").textContent = "Error: " + props.error.message; return; }
  ALL = props.data || [];
  NOTES = {};
  (notes.data || []).forEach(n => { (NOTES[n.property_id] = NOTES[n.property_id] || []).push(n); });
  FAVS = new Set((favs.data || []).map(r => r.property_id));
  HIDDEN = new Set((hid.data || []).map(r => r.property_id));

  const newest = ALL.reduce((a, p) => (p.updated_at > a ? p.updated_at : a), "");
  document.getElementById("generatedAt").textContent =
    newest ? "Data updated " + new Date(newest).toLocaleString() : "No data yet — run the sync script.";
  document.getElementById("eyebrow").textContent =
    "Field Ledger · " + countyNames().length + " Counties · " + BUILD;
}

// ------------------------------------------------------------------- chips
function buildChips(id, values, set, labelFn, classFn) {
  const el = document.getElementById(id);
  el.innerHTML = "";
  values.forEach(v => {
    const c = document.createElement("span");
    c.className = "chipx" + (set.has(v) ? " on" : "") + (classFn ? " " + classFn(v) : "");
    c.textContent = labelFn ? labelFn(v) : v;
    c.dataset.value = v;
    c.addEventListener("click", () => {
      set.has(v) ? set.delete(v) : set.add(v);
      c.classList.toggle("on");
      updateBadge(); render();
    });
    el.appendChild(c);
  });
}
function buildAllChips() {
  buildChips("countyChips", countyNames(), state.counties);
  buildChips("typeChips", TYPE_ORDER, state.types);
  buildChips("lienChips", LIEN_ORDER, state.liens, v => LIEN_LABEL[v], v => "lien-" + v);
}

// ------------------------------------------------------------------ filter
function passes(p) {
  if (HIDDEN.has(p.id)) return false;
  if (goneExpired(p)) return false;
  if (state.statusView === "gone" && !isGone(p)) return false;
  if (state.statusView === "live" && isGone(p)) return false;
  if (state.favoritesOnly && !FAVS.has(p.id)) return false;
  if (state.topPicksOnly && !isTopPick(p)) return false;
  if (state.soonOnly) { const d = daysUntil(p); if (d === null || d < 0 || d > SOON_DAYS) return false; }
  if (!state.counties.has(p.county)) return false;
  if (!state.types.has(propType(p))) return false;
  if (!state.liens.has(p.lien_level)) return false;
  if (state.bidMin !== null && Number(p.bid) < state.bidMin) return false;
  if (state.bidMax !== null && Number(p.bid) > state.bidMax) return false;
  if (state.assessedMin !== null && Number(p.assessed || 0) < state.assessedMin) return false;
  return true;
}

// -------------------------------------------------------------------- card
function noteHtml(p) {
  const rows = (NOTES[p.id] || []).slice().sort((a, b) => (a.updated_at < b.updated_at ? 1 : -1));
  const mine = rows.find(n => n.author_id === ME.id);
  const others = rows.filter(n => n.author_id !== ME.id);
  const list = others.map(n => `<div class="note-item"><span class="note-author">${esc((n.author_email || "teammate").split("@")[0])}</span>${n.stage ? `<span class="note-stage-tag">${esc(n.stage)}</span>` : ""}<br>${esc(n.body || "")}</div>`).join("");
  return `
  <div class="notes-block">
    <div class="notes-head"><span>Team notes${rows.length ? " (" + rows.length + ")" : ""}</span></div>
    ${list}
    <div class="note-editor">
      <select data-role="stage" data-pid="${p.id}">
        ${STAGES.map(s => `<option value="${s}"${mine && mine.stage === s ? " selected" : ""}>${s === "" ? "— stage —" : s}</option>`).join("")}
      </select>
      <textarea data-role="body" data-pid="${p.id}" rows="2" placeholder="Your note — visible to the team">${esc(mine ? mine.body : "")}</textarea>
      <button class="note-save" data-action="savenote" data-pid="${p.id}" type="button">Save note</button>
    </div>
  </div>`;
}

function card(p, showCounty) {
  const el = document.createElement("div");
  const fav = FAVS.has(p.id), top = isTopPick(p);
  el.className = "prop-card" + (fav ? " favorited" : "") + (top ? " toppick" : "");

  const d = daysUntil(p);
  let cd = "";
  if (d !== null && d >= 0) {
    const cls = d <= 3 ? "urgent" : d <= SOON_DAYS ? "soon" : "";
    cd = `<span class="countdown ${cls}">${d === 0 ? "TODAY" : d + "d"}</span>`;
  }
  const tag = showCounty
    ? `<div class="prop-county-tag">${esc(p.county)}${p.sale_date ? " · " + new Date(p.sale_date + "T00:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : ""}</div>`
    : (p.sale_date ? `<div class="prop-county-tag">Sale ${new Date(p.sale_date + "T00:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric" })}</div>` : "");

  el.innerHTML = `
    ${top ? `<div class="toppick-banner"> ⭐ Top pick <span class="ratio-pill">${valueRatio(p).toFixed(1)}x market vs bid</span></div>` : ""}
    ${tag}
    <div class="prop-top">
      <div class="prop-address">${esc(p.address)}</div>
      <div class="prop-top-actions">
        <button class="icon-btn heart-btn${fav ? " on" : ""}" data-action="fav" data-pid="${p.id}" type="button">${fav ? "♥" : "♡"}</button>
        <button class="icon-btn remove-btn" data-action="hide" data-pid="${p.id}" type="button">✕</button>
        ${cd}
        <span class="pill ${esc(p.status)}">${esc(p.status)}</span>
      </div>
    </div>
    <div class="prop-meta">
      <span>Parcel #${esc(p.parcel || "Unknown")}</span>
      <span class="meta-bid">Bid ${fmtMoney(p.bid)}</span>
      <span class="meta-assessed">Assessed ${fmtShort(p.assessed || 0)}</span>
      <span class="meta-market">Market ${p.market ? fmtShort(p.market) : "N/A"}</span>
    </div>
    <div class="cost-row">
      <span class="cost-item"><span class="cost-tag">True cost</span> <b>${fmtShort(trueCost(p))}</b>${p.homestead ? ' <span class="hs-flag">incl. homestead ½ assessed</span>' : ""}</span>
      <span class="cost-item ${Number(p.bid) > maxBid(p) ? "over" : "under"}"><span class="cost-tag">Walk away above</span> <b>${fmtShort(maxBid(p))}</b></span>
    </div>
    <div class="lien-banner ${esc(p.lien_level)}">
      <div class="lien-toprow">
        <span class="lien-label">Title: ${LIEN_LABEL[p.lien_level] || p.lien_level}</span>
        <span class="type-badge">${esc(p.prop_type || "Type: Unknown")}</span>
      </div>
      <span class="lien-text">${esc(p.lien_note || "")}</span>
    </div>
    <div class="copy-row">
      ${p.owner_name ? `<button class="copy-btn" data-action="copy" data-copy="${esc(p.owner_name)}" type="button"><span class="copy-tag">Owner</span><span class="copy-val">${esc(p.owner_name)}</span></button>` : ""}
      ${p.parcel && p.parcel !== "Unknown" ? `<button class="copy-btn" data-action="copy" data-copy="${esc(p.parcel)}" type="button"><span class="copy-tag">Parcel</span><span class="copy-val">${esc(p.parcel)}</span></button>` : ""}
    </div>
    <div class="prop-links">
      <a href="${esc(p.url_streetview)}" target="_blank" rel="noopener">Street View</a>
      <a href="${esc(p.url_appraiser)}" target="_blank" rel="noopener">Appraiser</a>
      <a href="${esc(p.url_zillow)}" target="_blank" rel="noopener">Zillow</a>
      <a href="${esc(p.url_taxcoll)}" target="_blank" rel="noopener">Tax Collector</a>
      <a href="${esc(p.url_auction)}" target="_blank" rel="noopener">${p.source === "laft" ? "LAFT Listing" : "Auction"}</a>
      <a href="${esc(p.url_title)}" target="_blank" rel="noopener">Title Search</a>
    </div>
    ${noteHtml(p)}`;
  return el;
}

// ------------------------------------------------------------------ render
function sortRows(rows) {
  const s = state.sortBy, out = rows.slice();
  if (s === "dateAsc") out.sort((a, b) => saleTime(a) - saleTime(b) || a.bid - b.bid);
  else if (s === "dateDesc") out.sort((a, b) => {
    const ta = saleTime(a), tb = saleTime(b);
    if (ta === Infinity && tb === Infinity) return 0;
    if (ta === Infinity) return 1; if (tb === Infinity) return -1;
    return tb - ta;
  });
  else if (s === "bidAsc") out.sort((a, b) => a.bid - b.bid);
  else if (s === "bidDesc") out.sort((a, b) => b.bid - a.bid);
  else if (s === "assessedAsc") out.sort((a, b) => (a.assessed || 0) - (b.assessed || 0));
  else if (s === "assessedDesc") out.sort((a, b) => (b.assessed || 0) - (a.assessed || 0));
  else if (s === "spreadDesc") out.sort((a, b) => valueRatio(b) - valueRatio(a));
  else if (s === "address") out.sort((a, b) => a.address.localeCompare(b.address));
  return out;
}

function emptyReason() {
  if (state.types.size === 0) return 'No property types selected — tap "All" under Property type.';
  if (state.liens.size === 0) return 'No title statuses selected — tap "All" under Title status.';
  if (state.counties.size === 0) return 'No counties selected — tap "All" under County.';
  return "No properties match these filters.";
}

function section(container, title, sub, rows, sourceTag) {
  const sec = document.createElement("section");
  sec.className = "mega-section";
  sec.innerHTML = `<div class="mega-head"><h2>${title}</h2><p class="mega-sub">${sub}</p></div>`;
  const shown = rows.filter(passes);
  
  if (!shown.length) {
    const e = document.createElement("div");
    e.className = "empty-state";
    e.textContent = rows.length ? emptyReason() : "Nothing in this section yet.";
    sec.appendChild(e); container.appendChild(sec);
    return [];
  }
  
  const live = sourceTag === "laft" ? "available" : "active";
  
  if (state.sortBy === "county") {
    countyNames().forEach(cn => {
      const cp = shown.filter(p => p.county === cn);
      if (!cp.length) return;
      
      const det = document.createElement("details");
      det.className = "county-group";
      det.open = isWide() || cp.some(p => p.status !== live);
      const nLive = cp.filter(p => p.status === live).length;
      const dates = Array.from(new Set(cp.map(p => p.sale_date).filter(Boolean))).sort();
      
      // Determine the Next Auction display dynamically
      let dateTxt = "Fixed price — no bidding";
      if (dates.length) {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        // Find dates that are today or in the future
        const futureDates = dates.filter(d => new Date(d + "T00:00:00") >= today);
        
        if (futureDates.length > 0) {
          const targetDate = futureDates[0];
          const isNext = dates.length > futureDates.length; // True if some dates have passed
          const formatted = new Date(targetDate + "T00:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
          dateTxt = (isNext ? "Next: " : "") + formatted + (futureDates.length > 1 ? ` (+${futureDates.length - 1} more)` : "");
        } else {
          // All known dates for this county have passed
          const lastDate = dates[dates.length - 1];
          const formatted = new Date(lastDate + "T00:00:00").toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
          dateTxt = "Last: " + formatted + " (Awaiting schedule)";
        }
      }
      
      det.innerHTML = `<summary class="county-head">
          <div><div class="county-name">${esc(cn)}</div><div class="county-meta">${dateTxt}</div></div>
          <div class="county-right"><span class="county-count">${nLive}/${cp.length} ${live}</span><span class="chevron"></span></div>
        </summary>`;
        
      const info = COUNTY_INFO[cn];
      if (info) {
        const bar = document.createElement("div");
        bar.className = "county-info";
        bar.innerHTML = `<span class="fmt-pill ${info.fmt === "In person" ? "inperson" : ""}">${info.fmt}</span><span>${info.note}</span>`;
        det.appendChild(bar);
      }
      
      const list = document.createElement("div");
      list.className = "prop-list";
      cp.forEach(p => list.appendChild(card(p, false)));
      det.appendChild(list);
      sec.appendChild(det);
    });
  } else {
    const list = document.createElement("div");
    list.className = "prop-list flat";
    sortRows(shown).forEach(p => list.appendChild(card(p, true)));
    sec.appendChild(list);
  }
  container.appendChild(sec);
  return shown;
}

function render() {
  const main = document.getElementById("main");
  main.innerHTML = "";
  const a = section(main, "Auctions &amp; Bidding", "Open to competitive bidding at a live county auction.", ALL.filter(p => p.source === "auction"), "auction");
  const l = section(main, "Lands Available for Taxes", "Failed to sell at auction — purchasable directly from the county at a fixed price, no bidding.", ALL.filter(p => p.source === "laft"), "laft");
  const shown = a.concat(l);

  // Counts deliberately ignore the status filter, so the chips stay a stable
  // reference — otherwise viewing "Gone" would report "Active 0".
  const saved = state.statusView;
  state.statusView = "all";
  const pool = ALL.filter(passes);
  state.statusView = saved;

  document.getElementById("chipTotal").textContent = pool.length;
  document.getElementById("chipActive").textContent = pool.filter(p => !isGone(p)).length;
  document.getElementById("chipGone").textContent = pool.filter(isGone).length;
  const hi = document.getElementById("hiddenInfo");
  document.getElementById("hiddenCount").textContent = HIDDEN.size;
  hi.hidden = HIDDEN.size === 0;
}

function updateBadge() {
  let n = 0;
  if (state.bidMin !== null) n++; if (state.bidMax !== null) n++;
  if (state.assessedMin !== null) n++; if (state.sortBy !== "county") n++;
  if (state.favoritesOnly) n++; if (state.topPicksOnly) n++; if (state.soonOnly) n++;
  if (state.statusView !== "all") n++;
  if (state.counties.size !== countyNames().length) n++;
  if (state.types.size !== TYPE_ORDER.length) n++;
  if (state.liens.size !== LIEN_ORDER.length) n++;
  const b = document.getElementById("filtersBadge");
  b.textContent = n; b.hidden = n === 0;
}

// ------------------------------------------------------------ interactions
document.getElementById("main").addEventListener("click", async e => {
  const btn = e.target.closest("[data-action]");
  if (!btn) return;
  const pid = btn.dataset.pid;
  const act = btn.dataset.action;

  if (act === "copy") {
    const v = btn.dataset.copy;
    const label = btn.querySelector(".copy-val");
    const orig = label.textContent;
    try { await navigator.clipboard.writeText(v); } catch (err) { /* older browsers */ }
    btn.classList.add("copied"); label.textContent = "Copied";
    setTimeout(() => { btn.classList.remove("copied"); label.textContent = orig; }, 1200);
    return;
  }
  if (act === "fav") {
    if (FAVS.has(pid)) { FAVS.delete(pid); await sb.from("favorites").delete().eq("property_id", pid).eq("user_id", ME.id); }
    else { FAVS.add(pid); await sb.from("favorites").insert({ user_id: ME.id, property_id: pid }); }
    render(); return;
  }
  if (act === "hide") {
    HIDDEN.add(pid);
    await sb.from("hidden").insert({ user_id: ME.id, property_id: pid });
    render(); return;
  }
  if (act === "savenote") {
    const block = btn.closest(".note-editor");
    const stage = block.querySelector("[data-role='stage']").value;
    const body = block.querySelector("[data-role='body']").value;
    const row = { property_id: pid, author_id: ME.id, author_email: ME.email, stage, body };
    const { error } = await sb.from("notes").upsert(row, { onConflict: "property_id,author_id" });
    if (error) { btn.textContent = "Error"; return; }
    const list = (NOTES[pid] = NOTES[pid] || []);
    const mine = list.find(n => n.author_id === ME.id);
    if (mine) { mine.stage = stage; mine.body = body; }
    else list.push(Object.assign({ updated_at: new Date().toISOString() }, row));
    btn.textContent = "Saved"; btn.classList.add("saved");
    setTimeout(() => { btn.textContent = "Save note"; btn.classList.remove("saved"); }, 1400);
    return;
  }
});

// Header chips double as a status filter. Tapping the active one clears it.
document.querySelectorAll(".chip[data-status]").forEach(chip => {
  chip.addEventListener("click", () => {
    const want = chip.dataset.status;
    state.statusView = (state.statusView === want || want === "all") ? "all" : want;
    document.querySelectorAll(".chip[data-status]").forEach(c =>
      c.classList.toggle("on", c.dataset.status === state.statusView && state.statusView !== "all"));
    updateBadge();
    render();
  });
});

document.getElementById("restoreHiddenBtn").addEventListener("click", async () => {
  HIDDEN.clear();
  await sb.from("hidden").delete().eq("user_id", ME.id);
  render();
});

const bind = (id, ev, fn) => document.getElementById(id).addEventListener(ev, fn);
bind("bidMin", "input", e => { state.bidMin = e.target.value === "" ? null : +e.target.value; updateBadge(); render(); });
bind("bidMax", "input", e => { state.bidMax = e.target.value === "" ? null : +e.target.value; updateBadge(); render(); });
bind("assessedMin", "input", e => { state.assessedMin = e.target.value === "" ? null : +e.target.value; updateBadge(); render(); });
bind("sortBy", "change", e => { state.sortBy = e.target.value; updateBadge(); render(); });
bind("favOnly", "change", e => { state.favoritesOnly = e.target.checked; updateBadge(); render(); });
bind("topOnly", "change", e => { state.topPicksOnly = e.target.checked; updateBadge(); render(); });
bind("soonOnly", "change", e => { state.soonOnly = e.target.checked; updateBadge(); render(); });
bind("qtToggle", "change", e => { state.includeQT = e.target.checked; render(); });
bind("maxBidPct", "input", e => { const v = +e.target.value; state.maxBidPct = v > 0 && v <= 100 ? v : 40; render(); });
bind("filtersToggle", "click", function () { this.classList.toggle("open"); document.getElementById("filtersPanel").classList.toggle("open"); });
bind("resetBtn", "click", () => {
  Object.assign(state, { bidMin: null, bidMax: null, assessedMin: null, sortBy: "county",
    favoritesOnly: false, topPicksOnly: false, soonOnly: false, statusView: "all",
    counties: new Set(countyNames()), types: new Set(TYPE_ORDER), liens: new Set(LIEN_ORDER) });
  document.querySelectorAll(".chip[data-status]").forEach(c => c.classList.remove("on"));
  ["bidMin", "bidMax", "assessedMin"].forEach(i => document.getElementById(i).value = "");
  document.getElementById("sortBy").value = "county";
  ["favOnly", "topOnly", "soonOnly"].forEach(i => document.getElementById(i).checked = false);
  buildAllChips(); updateBadge(); render();
});
document.querySelectorAll(".mini-btn").forEach(b => b.addEventListener("click", () => {
  const g = b.dataset.group;
  const vals = g === "types" ? TYPE_ORDER : g === "liens" ? LIEN_ORDER : countyNames();
  state[g] = b.dataset.mode === "all" ? new Set(vals) : new Set();
  buildAllChips(); updateBadge(); render();
}));

// ----------------------------------------------------------------- install
// Register the service worker so the app is installable and survives a weak
// signal. Failure here is non-fatal — the app works fine without it.
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register("sw.js").catch(() => {});
  });
}

// Chrome/Edge/Android fire this when the app qualifies for install; we stash
// the event and surface our own button. iOS Safari never fires it — there the
// user installs via Share -> Add to Home Screen, so we show a hint instead.
// Detecting "installed" by elimination proved unreliable inside a TWA — Chrome
// still fired beforeinstallprompt there. Invert it: only offer Install when we
// can positively confirm a plain browser tab. Anything else (TWA, standalone,
// minimal-ui, unknown) gets no button.
//
// The android-app:// referrer only appears on the TWA's first navigation, so
// latch it for the session — later in-app navigations would otherwise look
// like a browser.
if (document.referrer.startsWith("android-app://")) {
  try { sessionStorage.setItem("tdw_twa", "1"); } catch (e) {}
}
const launchedFromApk = (() => {
  try { return sessionStorage.getItem("tdw_twa") === "1"; } catch (e) { return false; }
})();

const inPlainBrowser =
  window.matchMedia("(display-mode: browser)").matches &&
  window.navigator.standalone !== true &&
  !launchedFromApk;

const runningInstalled = !inPlainBrowser;

let deferredInstall = null;
const installBtn = document.getElementById("installBtn");
window.addEventListener("beforeinstallprompt", e => {
  e.preventDefault();
  if (!inPlainBrowser) return;   // fires inside the TWA too; ignore it there
  deferredInstall = e;
  installBtn.hidden = false;
});
installBtn.addEventListener("click", async () => {
  if (deferredInstall) {
    deferredInstall.prompt();
    await deferredInstall.userChoice;
    deferredInstall = null;
    installBtn.hidden = true;
    return;
  }
  alert("On iPhone or iPad: tap the Share button, then \"Add to Home Screen\".");
});
window.addEventListener("appinstalled", () => { installBtn.hidden = true; });

// iOS never fires beforeinstallprompt, so surface the button there manually —
// but only in Safari, not inside the installed app.
const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
if (isIOS && inPlainBrowser) installBtn.hidden = false;

// Belt and braces: if anything above misjudges it, hide the button the moment
// the app reports itself as installed.
window.matchMedia("(display-mode: standalone)").addEventListener("change", e => {
  if (e.matches) installBtn.hidden = true;
});

// ------------------------------------------------------------ theme / view
const THEMES = ["auto", "light", "dark"];
const T_ICON = { auto: "🌓", light: "☀️", dark: "🌙" }, T_LABEL = { auto: "Auto", light: "Light", dark: "Dark" };
let theme = localStorage.getItem("tdw_theme") || "auto";
if (!THEMES.includes(theme)) theme = "auto";
function applyTheme(m) {
  m === "auto" ? document.documentElement.removeAttribute("data-theme")
               : document.documentElement.setAttribute("data-theme", m);
  document.getElementById("themeIcon").textContent = T_ICON[m];
  document.getElementById("themeLabel").textContent = T_LABEL[m];
}
applyTheme(theme);
bind("themeBtn", "click", () => {
  theme = THEMES[(THEMES.indexOf(theme) + 1) % 3];
  localStorage.setItem("tdw_theme", theme); applyTheme(theme);
});

// Layout is now purely responsive via CSS media queries — no toggle, no stored
// preference. The one thing JS still needs to know is whether we're wide, so
// county sections can default to expanded on a big screen.
const wideQuery = window.matchMedia("(min-width: 1024px)");
const isWide = () => wideQuery.matches;
wideQuery.addEventListener("change", () => { if (ME) render(); });
try { localStorage.removeItem("tdw_view"); } catch (e) {}